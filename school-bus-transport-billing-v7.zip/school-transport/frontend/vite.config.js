import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// `npm run build` writes the finished site straight into the Java backend,
// so http://localhost:8080 serves it (no separate web server needed).
export default defineConfig({
  plugins: [react()],
  build: {
    outDir: '../backend/src/main/resources/static',
    emptyOutDir: true,
  },
  server: {
    port: 5173,
    proxy: { '/api': { target: 'http://localhost:8080', changeOrigin: true } },
  },
});

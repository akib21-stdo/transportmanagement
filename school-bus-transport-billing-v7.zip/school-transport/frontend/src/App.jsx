import { useEffect, useState } from 'react';
import { api, token } from './api.js';
import { ENTITIES } from './entities.js';
import Login from './components/Login.jsx';
import Layout from './components/Layout.jsx';
import Dashboard from './components/Dashboard.jsx';
import CrudPage from './components/CrudPage.jsx';
import { Spinner } from './components/ui.jsx';

// Pages are chosen by the URL hash: #/buses, #/billing ...  (no router library needed)
const currentPage = () => {
  const key = window.location.hash.replace('#/', '');
  return ENTITIES[key] ? key : 'dashboard';
};

export default function App() {
  const [user, setUser] = useState(null);
  const [checking, setChecking] = useState(Boolean(token.get()));
  const [page, setPage] = useState(currentPage);

  // restore the session if a token is already saved
  useEffect(() => {
    if (!token.get()) return;
    api('/api/auth/me').then(setUser).catch(() => token.clear()).finally(() => setChecking(false));
  }, []);

  useEffect(() => {
    const onHash = () => setPage(currentPage());
    const onExpired = () => setUser(null);
    window.addEventListener('hashchange', onHash);
    window.addEventListener('auth:expired', onExpired);
    return () => {
      window.removeEventListener('hashchange', onHash);
      window.removeEventListener('auth:expired', onExpired);
    };
  }, []);

  const logout = () => { token.clear(); setUser(null); };

  if (checking) return <Spinner />;
  if (!user) return <Login onLogin={setUser} />;

  return (
    <Layout user={user} page={page} title={page === 'dashboard' ? 'Operational overview' : ENTITIES[page].title} onLogout={logout}>
      {page === 'dashboard' ? <Dashboard /> : <CrudPage key={page} entityKey={page} />}
    </Layout>
  );
}

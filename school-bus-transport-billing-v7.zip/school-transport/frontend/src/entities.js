// One place that describes every page: its form fields and table columns.
// CrudPage and EntityForm are generic and read everything from here.
export const CURRENCY = '৳';
export const money = (n) => `${CURRENCY}${Number(n || 0).toFixed(2)}`;

const status = (...values) => values.map((v) => ({ value: v, label: v[0].toUpperCase() + v.slice(1) }));
const sumBy = (rows, s) => rows.filter((r) => r.status === s).reduce((t, r) => t + Number(r.amount), 0);

export const ENTITIES = {
  buses: {
    title: 'Buses', singular: 'Bus', sub: 'Manage the fleet',
    fields: [
      { name: 'bus_number', label: 'Bus Number', required: true, placeholder: 'BUS-01' },
      { name: 'plate_number', label: 'Plate Number' },
      { name: 'capacity', label: 'Capacity', type: 'number', min: 0, default: 0 },
      { name: 'model', label: 'Model' },
      { name: 'driver_id', label: 'Driver', type: 'select', from: 'drivers', optionLabel: (d) => d.name, filter: (d) => d.status === 'active', empty: 'Unassigned' },
      { name: 'status', label: 'Status', type: 'select', options: status('active', 'maintenance', 'inactive'), default: 'active' },
    ],
    columns: [
      { label: 'Bus No.', get: (r) => r.bus_number, strong: true },
      { label: 'Plate', get: (r) => r.plate_number },
      { label: 'Capacity', get: (r) => r.capacity },
      { label: 'Model', get: (r) => r.model },
      { label: 'Driver', get: (r) => r.drivers?.name || 'Unassigned' },
      { label: 'Status', get: (r) => r.status, badge: true },
    ],
  },
  drivers: {
    title: 'Drivers', singular: 'Driver', sub: 'Manage bus drivers',
    fields: [
      { name: 'name', label: 'Full Name', required: true, placeholder: 'John Smith' },
      { name: 'phone', label: 'Phone', placeholder: '01711-000000' },
      { name: 'email', label: 'Email', type: 'email', placeholder: 'driver@example.com' },
      { name: 'license_number', label: 'License Number', placeholder: 'DL-1001' },
      { name: 'status', label: 'Status', type: 'select', options: status('active', 'inactive'), default: 'active' },
    ],
    columns: [
      { label: 'Name', get: (r) => r.name, strong: true },
      { label: 'Phone', get: (r) => r.phone },
      { label: 'Email', get: (r) => r.email },
      { label: 'License', get: (r) => r.license_number },
      { label: 'Status', get: (r) => r.status, badge: true },
    ],
  },
  routes: {
    title: 'Routes', singular: 'Route', sub: 'Plan bus routes and timings',
    fields: [
      { name: 'route_name', label: 'Route Name', required: true, placeholder: 'Route A - North Side' },
      { name: 'start_point', label: 'Start Point', placeholder: 'School Campus' },
      { name: 'end_point', label: 'End Point', placeholder: 'North District' },
      { name: 'departure_time', label: 'Departure Time', type: 'time' },
      { name: 'arrival_time', label: 'Arrival Time', type: 'time' },
      { name: 'bus_id', label: 'Assigned Bus', type: 'select', from: 'buses', optionLabel: (b) => b.bus_number, empty: 'Unassigned' },
    ],
    columns: [
      { label: 'Route Name', get: (r) => r.route_name, strong: true },
      { label: 'Path', get: (r) => `${r.start_point || '—'}  →  ${r.end_point || '—'}` },
      { label: 'Departure', get: (r) => r.departure_time },
      { label: 'Arrival', get: (r) => r.arrival_time },
      { label: 'Bus', get: (r) => r.buses?.bus_number || 'Unassigned' },
    ],
  },
  students: {
    title: 'Students', singular: 'Student', sub: 'Manage students and their routes',
    fields: [
      { name: 'name', label: 'Student Name', required: true },
      { name: 'grade', label: 'Grade', placeholder: 'Class 5' },
      { name: 'phone', label: 'Phone' },
      { name: 'parent_name', label: 'Parent Name' },
      { name: 'parent_phone', label: 'Parent Phone' },
      { name: 'address', label: 'Address' },
      { name: 'route_id', label: 'Route', type: 'select', from: 'routes', optionLabel: (r) => r.route_name, empty: 'Unassigned' },
    ],
    columns: [
      { label: 'Name', get: (r) => r.name, strong: true },
      { label: 'Grade', get: (r) => r.grade },
      { label: 'Parent', get: (r) => r.parent_name },
      { label: 'Parent Phone', get: (r) => r.parent_phone },
      { label: 'Route', get: (r) => r.routes?.route_name || 'Unassigned' },
    ],
  },
  billing: {
    title: 'Billing', singular: 'Invoice', sub: 'Track transport fees',
    fields: [
      { name: 'student_id', label: 'Student', type: 'select', required: true, from: 'students', optionLabel: (s) => s.name, empty: 'Select a student' },
      { name: 'amount', label: `Amount (${CURRENCY})`, type: 'number', required: true, min: 0, step: '0.01', placeholder: '1500.00' },
      { name: 'status', label: 'Status', type: 'select', options: status('pending', 'paid', 'overdue'), default: 'pending' },
      { name: 'due_date', label: 'Due Date', type: 'date' },
      { name: 'paid_date', label: 'Paid Date', type: 'date', showWhen: { status: 'paid' } },
      { name: 'description', label: 'Description', placeholder: 'Monthly transport fee - October' },
    ],
    columns: [
      { label: 'Student', get: (r) => r.students?.name || 'Unknown', strong: true },
      { label: 'Amount', get: (r) => money(r.amount), strong: true },
      { label: 'Status', get: (r) => r.status, badge: true },
      { label: 'Due', get: (r) => r.due_date },
      { label: 'Paid On', get: (r) => r.paid_date },
      { label: 'Description', get: (r) => r.description },
    ],
    // small totals strip shown above the table
    summary: (rows) => [
      { label: 'Collected', value: money(sumBy(rows, 'paid')), cls: 'stat-paid' },
      { label: 'Pending', value: money(sumBy(rows, 'pending')) },
      { label: 'Overdue', value: money(sumBy(rows, 'overdue')), cls: 'stat-overdue' },
    ],
  },
};

export const NAV = [
  ['dashboard', 'Dashboard'],
  ...['buses', 'drivers', 'routes', 'students', 'billing'].map((k) => [k, ENTITIES[k].title]),
];

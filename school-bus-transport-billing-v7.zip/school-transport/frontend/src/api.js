// Tiny fetch wrapper for the Spring Boot API (adds the login token, turns errors into messages).
const TOKEN_KEY = 'busfleet_token';

export const token = {
  get: () => localStorage.getItem(TOKEN_KEY),
  set: (t) => localStorage.setItem(TOKEN_KEY, t),
  clear: () => localStorage.removeItem(TOKEN_KEY),
};

export async function api(path, { method = 'GET', body } = {}) {
  const headers = {};
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (token.get()) headers.Authorization = `Bearer ${token.get()}`;

  let res;
  try {
    res = await fetch(path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  } catch {
    throw new Error('Cannot reach the server. Is the backend running?');
  }

  if (res.status === 401 && !path.startsWith('/api/auth/login')) {
    token.clear();
    window.dispatchEvent(new Event('auth:expired'));
    throw new Error('Session expired. Please sign in again.');
  }
  if (!res.ok) {
    let message = `Request failed (${res.status})`;
    try {
      const data = await res.json();
      if (data?.error) message = data.error;
    } catch { /* no JSON body */ }
    throw new Error(message);
  }
  return res.status === 204 ? null : res.json();
}

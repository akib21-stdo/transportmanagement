// Small shared pieces: icons, status badge, loading spinner, error box.
const PATHS = {
  dashboard: '<rect x="3" y="3" width="7" height="9" rx="1"/><rect x="14" y="3" width="7" height="5" rx="1"/><rect x="14" y="12" width="7" height="9" rx="1"/><rect x="3" y="16" width="7" height="5" rx="1"/>',
  buses: '<path d="M8 6v6m8-6v6M4 17V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v11H4Z"/><path d="M4 13h16M5 17v2a1 1 0 0 0 2 0v-2m10 0v2a1 1 0 0 0 2 0v-2"/>',
  drivers: '<circle cx="12" cy="8" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2"/>',
  routes: '<circle cx="6" cy="19" r="2"/><circle cx="18" cy="5" r="2"/><path d="M8 19h6a4 4 0 0 0 0-8h-4a4 4 0 0 1 0-8h6"/>',
  students: '<path d="m2 10 10-5 10 5-10 5-10-5Zm4 2v5c3 3 9 3 12 0v-5M22 10v7"/>',
  billing: '<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20M6 15h3"/>',
  logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4m7 14 5-5-5-5m5 5H9"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
  edit: '<path d="M12 20h9M16.5 3.5a2.12 2.12 0 0 1 3 3L9 17l-4 1 1-4 10.5-10.5Z"/>',
  delete: '<path d="M3 6h18m-2 0-1 14H6L5 6m3 0V4h8v2m-6 4v7m4-7v7"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  close: '<path d="M18 6 6 18M6 6l12 12"/>',
  arrow: '<path d="M5 12h14m-6-6 6 6-6 6"/>',
};

export function Icon({ name, size = 18 }) {
  return (
    <svg
      aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"
      dangerouslySetInnerHTML={{ __html: PATHS[name] || PATHS.dashboard }}
    />
  );
}

const KNOWN = ['active', 'paid', 'pending', 'overdue', 'maintenance', 'inactive'];

export function Badge({ value }) {
  return <span className={`badge badge-${KNOWN.includes(value) ? value : 'neutral'}`}>{value || 'Unassigned'}</span>;
}

export const Spinner = () => <div className="spinner" />;
export const ErrorBox = ({ children }) => <div className="error" role="alert">{children}</div>;
export const LiveBadge = () => <span className="live-badge"><i /> DATABASE CONNECTED</span>;

import { useEffect, useState } from 'react';
import { api } from '../api.js';
import { money } from '../entities.js';
import { Badge, ErrorBox, Icon, LiveBadge, Spinner } from './ui.jsx';

const TABLES = ['drivers', 'students', 'buses', 'routes', 'billing'];

const Metric = ({ label, value, note, cls }) => (
  <section className={`panel metric ${cls}`}>
    <span className="eyebrow">{label}</span><strong>{value}</strong><small>{note}</small>
  </section>
);

const More = ({ to, children }) => (
  <a className="text-link" href={`#/${to}`}>{children} <Icon name="arrow" size={15} /></a>
);

export default function Dashboard() {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    Promise.all(TABLES.map((t) => api(`/api/${t}`)))
      .then((lists) => setData(Object.fromEntries(TABLES.map((t, i) => [t, lists[i]]))))
      .catch((e) => setError(e.message));
  }, []);

  if (error) return <ErrorBox>{error}</ErrorBox>;
  if (!data) return <Spinner />;

  const { drivers, students, buses, routes, billing } = data;
  const total = (s) => billing.filter((b) => b.status === s).reduce((t, b) => t + Number(b.amount), 0);
  const onRoad = buses.filter((b) => b.status === 'active').length;

  return (
    <>
      <div className="dashboard-heading">
        <div>
          <p className="eyebrow">LIVE OPERATIONS / OVERVIEW</p>
          <h2>Good to see you.</h2>
          <p>Your school transport network at a glance.</p>
        </div>
        <LiveBadge />
      </div>

      <div className="dashboard-grid">
        <Metric label="BUSES ON ROAD" value={onRoad} note={`${buses.length - onRoad} not active`} cls="metric-feature" />

        <section className="panel routes-panel">
          <div className="panel-heading"><h3>Route activity</h3><span className="panel-count">{routes.length} routes scheduled</span></div>
          <div className="route-list">
            {routes.length === 0 && <p className="empty">No routes yet.</p>}
            {routes.slice(0, 5).map((r, i) => (
              <div className="route-row" key={r.id}>
                <span className="route-code">R{String(i + 1).padStart(2, '0')}</span>
                <div className="route-info">
                  <strong>{r.route_name}</strong>
                  <small>{r.start_point || 'Start not set'} → {r.end_point || 'End not set'}</small>
                </div>
                <span className="route-bus">{r.buses?.bus_number || 'Unassigned'}</span>
              </div>
            ))}
          </div>
          <More to="routes">View all routes</More>
        </section>

        <Metric label="ACTIVE DRIVERS" value={drivers.filter((d) => d.status === 'active').length} note={`${drivers.length} drivers total`} cls="metric-small" />
        <Metric label="ENROLLED STUDENTS" value={students.length} note="Across all routes" cls="metric-small" />

        <section className="panel roster-panel">
          <div className="panel-heading"><h3>Driver roster</h3><span className="panel-count">{drivers.length} total</span></div>
          <div className="roster-head"><span>DRIVER</span><span>CONTACT</span><span>STATUS</span></div>
          {drivers.length === 0 && <p className="empty">No drivers yet.</p>}
          {drivers.slice(0, 4).map((d) => (
            <div className="roster-row" key={d.id}>
              <strong>{d.name}</strong><span>{d.phone || '—'}</span><Badge value={d.status} />
            </div>
          ))}
          <More to="drivers">View drivers</More>
        </section>

        <section className="panel billing-panel">
          <div className="panel-heading"><h3>Billing &amp; revenue</h3><span className="panel-count">All records</span></div>
          <div className="billing-metrics">
            <div><span>Collected</span><strong>{money(total('paid'))}</strong></div>
            <div><span>Pending</span><strong>{money(total('pending'))}</strong></div>
            <div><span>Overdue</span><strong>{money(total('overdue'))}</strong></div>
          </div>
          <More to="billing">View billing</More>
        </section>

        <section className="panel fleet-panel">
          <span className="eyebrow">FLEET HEALTH</span>
          <strong>{buses.filter((b) => b.status === 'maintenance').length}</strong>
          <small>Vehicles in maintenance</small>
          <div className="fleet-divider" />
          <span>{buses.length} total vehicles</span>
        </section>
      </div>
    </>
  );
}

import { useEffect, useState } from 'react';
import { api } from '../api.js';
import { Icon, ErrorBox } from './ui.jsx';

// Add / edit popup. `row` is null when adding a new record.
export default function EntityForm({ entityKey, ent, row, onClose, onSaved }) {
  const [values, setValues] = useState(() =>
    Object.fromEntries(ent.fields.map((f) => [f.name, row?.[f.name] ?? f.default ?? '']))
  );
  const [lookups, setLookups] = useState({});   // dropdown data, e.g. drivers for the Bus form
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    ent.fields.filter((f) => f.from).forEach((f) =>
      api(`/api/${f.from}`).then((list) => setLookups((l) => ({ ...l, [f.name]: list }))).catch((e) => setError(e.message))
    );
  }, [ent]);

  const set = (name, value) => setValues((v) => ({ ...v, [name]: value }));
  const visible = (f) => !f.showWhen || Object.entries(f.showWhen).every(([k, v]) => values[k] === v);

  const optionsFor = (f) =>
    f.from
      ? [{ value: '', label: f.empty || 'None' }, ...(lookups[f.name] || []).filter(f.filter || (() => true)).map((i) => ({ value: i.id, label: f.optionLabel(i) }))]
      : f.options;

  async function submit(e) {
    e.preventDefault();
    setError('');

    const payload = {};
    for (const f of ent.fields) {
      let v = typeof values[f.name] === 'string' ? values[f.name].trim() : values[f.name];
      if (f.required && v === '') return setError(`${f.label.replace(/ \(.*\)/, '')} is required`);
      if (f.type === 'number') v = v === '' ? f.default ?? null : Number(v);
      else if (v === '') v = null;
      payload[f.name] = v;
    }
    if (entityKey === 'billing') {
      if (!(payload.amount > 0)) return setError('Amount must be greater than 0');
      if (payload.status !== 'paid') payload.paid_date = null;
    }

    setSaving(true);
    try {
      await api(`/api/${entityKey}${row ? `/${row.id}` : ''}`, { method: row ? 'PUT' : 'POST', body: payload });
      onSaved();
    } catch (err) {
      setError(err.message);
      setSaving(false);
    }
  }

  return (
    <div className="backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal" role="dialog" aria-modal="true">
        <div className="modal-head">
          <div>
            <p className="eyebrow">BUSFLEET / {ent.title.toUpperCase()}</p>
            <h3>{row ? 'Edit' : 'Add New'} {ent.singular}</h3>
          </div>
          <button type="button" className="icon-btn" onClick={onClose} aria-label="Close"><Icon name="close" /></button>
        </div>
        {error && <ErrorBox>{error}</ErrorBox>}
        <form onSubmit={submit} noValidate>
          <div className="grid2">
            {ent.fields.filter(visible).map((f, i) => (
              <div className="field" key={f.name}>
                <label htmlFor={f.name}>{f.label}{f.required && ' *'}</label>
                {f.type === 'select' ? (
                  <select id={f.name} className="input" value={values[f.name]} onChange={(e) => set(f.name, e.target.value)}>
                    {optionsFor(f).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                  </select>
                ) : (
                  <input
                    id={f.name} className="input" type={f.type || 'text'} value={values[f.name]}
                    placeholder={f.placeholder} min={f.min} step={f.step} autoFocus={i === 0}
                    onChange={(e) => set(f.name, e.target.value)}
                  />
                )}
              </div>
            ))}
          </div>
          <div className="footer">
            <button type="button" className="btn btn-ghost" onClick={onClose}>Cancel</button>
            <button className="btn btn-primary" disabled={saving}>{row ? 'Save Changes' : 'Create'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}

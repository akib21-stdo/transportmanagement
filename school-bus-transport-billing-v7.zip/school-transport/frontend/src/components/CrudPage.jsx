import { useCallback, useEffect, useState } from 'react';
import { api } from '../api.js';
import { ENTITIES } from '../entities.js';
import { Badge, ErrorBox, Icon, LiveBadge, Spinner } from './ui.jsx';
import EntityForm from './EntityForm.jsx';

// One generic list page used for buses, drivers, routes, students and billing.
export default function CrudPage({ entityKey }) {
  const ent = ENTITIES[entityKey];
  const [rows, setRows] = useState(null);
  const [error, setError] = useState('');
  const [query, setQuery] = useState('');
  const [editing, setEditing] = useState(undefined); // undefined = closed, null = new, object = edit

  const load = useCallback(() => {
    api(`/api/${entityKey}`).then(setRows).catch((e) => setError(e.message));
  }, [entityKey]);

  useEffect(() => {
    setRows(null); setError(''); setQuery(''); setEditing(undefined);
    load();
  }, [load]);

  async function remove(row) {
    if (!window.confirm(`Delete this ${ent.singular.toLowerCase()}? This cannot be undone.`)) return;
    try {
      await api(`/api/${entityKey}/${row.id}`, { method: 'DELETE' });
      load();
    } catch (e) {
      alert(e.message);
    }
  }

  if (error && !rows) return <ErrorBox>{error}</ErrorBox>;
  if (!rows) return <Spinner />;

  const q = query.trim().toLowerCase();
  const shown = q ? rows.filter((r) => ent.columns.some((c) => String(c.get(r) ?? '').toLowerCase().includes(q))) : rows;
  const name = ent.title.toLowerCase();

  return (
    <>
      <div className="directory-heading">
        <div>
          <p className="eyebrow">BUSFLEET / {ent.title.toUpperCase()}</p>
          <h2>{ent.title} directory</h2>
          <p>{ent.sub} · {rows.length} records</p>
        </div>
        <LiveBadge />
      </div>

      {ent.summary && (
        <div className="stat-strip">
          {ent.summary(rows).map((s) => (
            <div key={s.label} className={`panel stat ${s.cls || ''}`}><span>{s.label}</span><strong>{s.value}</strong></div>
          ))}
        </div>
      )}

      <div className="panel directory-panel">
        <div className="directory-toolbar">
          <div><h3>All {name}</h3><span>{rows.length} records</span></div>
          <div className="toolbar">
            <label className="search-wrap">
              <Icon name="search" size={16} />
              <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={`Search ${name}...`} aria-label={`Search ${name}`} />
            </label>
            <button className="btn btn-primary" onClick={() => setEditing(null)}><Icon name="plus" size={17} /> Add {ent.singular}</button>
          </div>
        </div>

        <div className="table-scroll">
          {shown.length === 0 ? (
            <div className="empty">{rows.length ? 'No matches found' : `No ${name} yet. Click "Add ${ent.singular}" to create one.`}</div>
          ) : (
            <table>
              <thead>
                <tr>{ent.columns.map((c) => <th key={c.label}>{c.label}</th>)}<th /></tr>
              </thead>
              <tbody>
                {shown.map((r) => (
                  <tr key={r.id}>
                    {ent.columns.map((c) => {
                      const v = c.get(r);
                      const empty = v === null || v === undefined || v === '';
                      if (c.badge && !empty) return <td key={c.label}><Badge value={v} /></td>;
                      return <td key={c.label} className={c.strong ? 'strong' : ''}>{empty ? '—' : v}</td>;
                    })}
                    <td className="actions">
                      <button className="icon-btn" title="Edit" aria-label={`Edit ${ent.singular}`} onClick={() => setEditing(r)}><Icon name="edit" size={17} /></button>
                      <button className="icon-btn danger-icon" title="Delete" aria-label={`Delete ${ent.singular}`} onClick={() => remove(r)}><Icon name="delete" size={17} /></button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
        <div className="table-footer">
          Showing {shown.length} of {rows.length} records <span>BUSFLEET / {ent.title.toUpperCase()}</span>
        </div>
      </div>

      {editing !== undefined && (
        <EntityForm
          entityKey={entityKey} ent={ent} row={editing}
          onClose={() => setEditing(undefined)}
          onSaved={() => { setEditing(undefined); load(); }}
        />
      )}
    </>
  );
}

import { useState } from 'react';
import { api, token } from '../api.js';
import { Icon, ErrorBox } from './ui.jsx';

export default function Login({ onLogin }) {
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    const f = e.target.elements;
    setError('');
    setBusy(true);
    try {
      const res = await api('/api/auth/login', { method: 'POST', body: { email: f.email.value, password: f.password.value } });
      token.set(res.token);
      onLogin(res.user);
    } catch (err) {
      setError(err.message);
      setBusy(false);
    }
  }

  return (
    <div className="login-page">
      <div className="login-brand">
        <div className="brand-mark">B</div><span>School Bus</span>
        <span className="login-brand-tag">TRANSPORT &amp; BILLING</span>
      </div>
      <div className="login-layout">
        <div className="login-intro">
          <p className="eyebrow">SCHOOL BUS TRANSPORT / BILLING</p>
          <h1>Every journey,<br /><em>under control.</em></h1>
          <p>One workspace for your fleet, routes, drivers, students and transport fees.</p>
          <div className="login-rule" />
          <span>School Bus Transport &amp; Billing System</span>
        </div>
        <div className="login-card">
          <div className="login-card-top">
            <span className="login-symbol"><Icon name="buses" size={24} /></span>
            <p className="eyebrow">WELCOME TO BUSFLEET</p>
            <h2>Access your workspace</h2>
            <p>Sign in to manage your transport network.</p>
          </div>
          {error && <ErrorBox>{error}</ErrorBox>}
          <form onSubmit={submit}>
            <div className="field">
              <label htmlFor="email">Email address</label>
              <input id="email" name="email" className="input" type="email" required placeholder="you@school.com" autoComplete="username" />
            </div>
            <div className="field">
              <label htmlFor="password">Password</label>
              <input id="password" name="password" className="input" type="password" required placeholder="Enter your password" autoComplete="current-password" />
            </div>
            <button className="btn btn-primary btn-block" disabled={busy}>Sign in <Icon name="arrow" size={17} /></button>
          </form>
          <p className="login-foot">Authorized access only</p>
        </div>
      </div>
    </div>
  );
}

import { useState } from 'react';
import { NAV } from '../entities.js';
import { Icon } from './ui.jsx';

export default function Layout({ user, page, title, onLogout, children }) {
  const [open, setOpen] = useState(false);
  const initials = (user.name || user.email || 'U').slice(0, 2).toUpperCase();

  return (
    <div className="shell">
      <aside className={`sidebar${open ? ' open' : ''}`}>
        <div className="brand-row">
          <div className="logo-sm">B</div>
          <div><strong>School Bus</strong><small>TRANSPORT &amp; BILLING</small></div>
          <button className="mobile-close icon-btn" onClick={() => setOpen(false)} aria-label="Close menu"><Icon name="close" /></button>
        </div>
        <p className="nav-label">WORKSPACE</p>
        <nav className="nav">
          {NAV.map(([key, label]) => (
            <a key={key} href={`#/${key}`} className={key === page ? 'active' : ''} onClick={() => setOpen(false)}>
              <Icon name={key} /><span>{label}</span>
            </a>
          ))}
        </nav>
        <div className="user-box">
          <div className="avatar">{initials}</div>
          <div className="user-details"><strong>{user.name || 'Administrator'}</strong><small>{user.email}</small></div>
          <button className="icon-btn" onClick={onLogout} title="Sign out" aria-label="Sign out"><Icon name="logout" size={17} /></button>
        </div>
      </aside>
      <div className="mobile-scrim" onClick={() => setOpen(false)} />

      <div className="main-area">
        <header className="topbar">
          <button className="mobile-menu icon-btn" onClick={() => setOpen(true)} aria-label="Open menu"><Icon name="menu" /></button>
          <div><h1>{title}</h1><p>School bus transport &amp; billing</p></div>
          <div className="topbar-right">
            <span className="system-pill"><i /> System overview</span>
            <div className="top-avatar">{initials}</div>
          </div>
        </header>
        <main className="main">{children}</main>
        <footer className="app-footer">
          <span>School Bus Transport &amp; Billing System</span>
          <span>Connected to your school transport database</span>
        </footer>
      </div>
    </div>
  );
}

@echo off
title School Bus - Start
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo [X] Node.js not found. Install the LTS version from https://nodejs.org then run this again.
  pause & exit /b 1
)

echo === 1/2  Building the website (React) ===
cd /d "%~dp0frontend"
if not exist node_modules call npm install
call npm run build
if errorlevel 1 (
  echo [X] Build failed. Read the error above.
  pause & exit /b 1
)

echo.
echo === 2/2  Starting the server ===
cd /d "%~dp0backend"
where mvn >nul 2>nul
if errorlevel 1 (
  echo [!] Maven ^(mvn^) not found in PATH.
  echo     Website is built. Now start the backend from VS Code: press F5 ^(Backend - Spring Boot^).
  pause & exit /b 0
)
start "" http://localhost:8080
call mvn spring-boot:run
pause

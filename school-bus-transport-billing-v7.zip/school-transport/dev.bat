@echo off
title School Bus - Design mode
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo [X] Node.js not found. Install the LTS version from https://nodejs.org
  pause & exit /b 1
)

where mvn >nul 2>nul
if not errorlevel 1 (
  start "Backend" cmd /k "cd /d "%~dp0backend" && mvn spring-boot:run"
) else (
  echo [!] Maven not found. Start the backend yourself from VS Code ^(F5^) so login and data work.
)

cd /d "%~dp0frontend"
if not exist node_modules call npm install
start "" http://localhost:5173
call npm run dev
pause

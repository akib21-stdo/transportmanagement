# School Bus Transport & Billing

Java 21 + Spring Boot 3 + MySQL backend, React (Vite) frontend.

```
school-transport/
├── database/   workbench_setup.sql (সব একসাথে) + queries.sql (রিপোর্ট)
├── backend/    Spring Boot API + JWT login  (React build এখানেই serve হয়)
└── frontend/   React source code
```

## চালানোর নিয়ম (সবচেয়ে সহজ)

প্রথমবার শুধু একবার: MySQL Workbench-এ `database/workbench_setup.sql` চালান, আর Node.js (LTS) install করুন।

| কী করতে চান | কী করবেন |
|---|---|
| **সাইট চালাতে** | `start.bat` ডাবল-ক্লিক → ব্রাউজারে http://localhost:8080 |
| **ডিজাইন/কোড বদলাতে** | `dev.bat` ডাবল-ক্লিক → http://localhost:5173 (Save করলেই লাইভ বদলায়) |

লগইন: `admin@busfleet.com` / `Admin@123`

### Frontend বদলানোর পর
1. `dev.bat` চালিয়ে `frontend/src` এর ফাইল বদলান ও ব্রাউজারে দেখুন।
2. ঠিক হলে চলতে থাকা backend বন্ধ করুন (Ctrl + C) এবং `start.bat` চালান। এটা নতুন করে build করে সার্ভার চালু করে।
3. ব্রাউজারে Ctrl + F5।

### হাতে চালাতে চাইলে
```bash
cd frontend && npm install && npm run build     # সাইট build
cd ../backend && mvn spring-boot:run            # সার্ভার
```

MySQL পাসওয়ার্ড `root` না হলে `DB_PASSWORD` environment variable দিন
(অথবা `application.properties` বদলান)। লগইন বদলাতে `LOGIN_EMAIL` / `LOGIN_PASSWORD`।
Deploy-এর আগে `JWT_SECRET` ও লগইন পাসওয়ার্ড অবশ্যই বদলাবেন।

## Frontend কীভাবে সাজানো
| ফাইল | কাজ |
|---|---|
| `src/entities.js` | **সব পেজের ফিল্ড ও কলাম এক জায়গায়** — নতুন ফিল্ড যোগ করতে শুধু এটা বদলান |
| `src/components/CrudPage.jsx` | Buses/Drivers/Routes/Students/Billing — একই generic পেজ |
| `src/components/EntityForm.jsx` | Add / Edit popup |
| `src/components/Dashboard.jsx` | ওভারভিউ |
| `src/components/Login.jsx`, `Layout.jsx` | লগইন, সাইডবার/টপবার |
| `src/api.js` | fetch + টোকেন |
| `src/styles.css` | পুরো ডিজাইন (Ink + Lime) |

## API
`/api/auth/login` ছাড়া সবকিছুতে `Authorization: Bearer <token>` লাগে।

| Method | Route | কাজ |
|---|---|---|
| POST | /api/auth/login | `{email, password}` → `{token, user}` |
| GET | /api/auth/me | বর্তমান ইউজার |
| GET, POST | /api/{drivers,buses,routes,students,billing} | list / create |
| GET, PUT, DELETE | /api/{table}/{id} | read / update / delete |

## সমস্যা হলে
- **Access denied for user 'root'** → DB পাসওয়ার্ড ভুল।
- **Unknown database 'school_transport'** → `workbench_setup.sql` চালানো হয়নি।
- **সাদা/পুরোনো পেজ** → `npm run build` চালান, তারপর Ctrl+F5।
- **Cannot reach the server** → backend চালু নেই।

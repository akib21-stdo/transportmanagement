-- Handy queries to try in MySQL Workbench (run after workbench_setup.sql)
USE school_transport;

SELECT * FROM dashboard_stats;                 -- totals + revenue
SELECT * FROM route_summary;                   -- route, bus, driver, student count
SELECT * FROM billing_details ORDER BY due_date;

SELECT * FROM users;                           -- login accounts (hashed passwords)
SELECT * FROM drivers;
SELECT * FROM buses;
SELECT * FROM students;

-- Unpaid invoices
SELECT student_name, amount, status, due_date
FROM billing_details
WHERE status <> 'paid'
ORDER BY due_date;

-- Students per bus
SELECT bu.bus_number, COUNT(st.id) AS students
FROM buses bu
LEFT JOIN routes r    ON r.bus_id = bu.id
LEFT JOIN students st ON st.route_id = r.id
GROUP BY bu.bus_number;

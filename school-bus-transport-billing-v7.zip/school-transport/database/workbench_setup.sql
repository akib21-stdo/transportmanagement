-- =====================================================================
--  BusFleet - ONE-CLICK MySQL Workbench setup
--  1) File > Open SQL Script > pick this file
--  2) Click the lightning icon  (runs everything)
--  3) Left panel > SCHEMAS > right click > Refresh All
--
--  Creates: database, tables, triggers, views, the admin login and demo data.
--  Admin login:  admin@busfleet.com  /  Admin@123
-- =====================================================================

-- =====================================================================
--  School Transport (BusFleet) - MySQL 8.0+ schema
--  Open in MySQL Workbench:  File > Open SQL Script > run all (lightning icon)
--  Safe to re-run: it drops and recreates the database.
-- =====================================================================

DROP DATABASE IF EXISTS school_transport;
CREATE DATABASE school_transport
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE school_transport;

-- ---------------------------------------------------------------------
-- users : login accounts (passwords are stored as BCrypt hashes)
-- The first admin account is created automatically by the backend.
-- ---------------------------------------------------------------------
CREATE TABLE users (
  id            CHAR(36)     NOT NULL DEFAULT (UUID()),
  name          VARCHAR(100) NOT NULL,
  email         VARCHAR(150) NOT NULL,
  password_hash VARCHAR(100) NOT NULL,
  role          VARCHAR(20)  NOT NULL DEFAULT 'STAFF',
  created_at    DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email (email),
  CONSTRAINT chk_users_role CHECK (role IN ('ADMIN','STAFF'))
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- drivers
-- ---------------------------------------------------------------------
CREATE TABLE drivers (
  id             CHAR(36)     NOT NULL DEFAULT (UUID()),
  name           VARCHAR(100) NOT NULL,
  phone          VARCHAR(30)  NULL,
  email          VARCHAR(150) NULL,
  license_number VARCHAR(50)  NULL,
  status         VARCHAR(20)  NOT NULL DEFAULT 'active',
  created_at     DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id),
  UNIQUE KEY uq_drivers_license (license_number),
  KEY idx_drivers_status (status),
  CONSTRAINT chk_drivers_status CHECK (status IN ('active','inactive'))
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- buses
-- ---------------------------------------------------------------------
CREATE TABLE buses (
  id           CHAR(36)     NOT NULL DEFAULT (UUID()),
  bus_number   VARCHAR(30)  NOT NULL,
  plate_number VARCHAR(40)  NULL,
  capacity     INT          NULL DEFAULT 0,
  model        VARCHAR(80)  NULL,
  status       VARCHAR(20)  NOT NULL DEFAULT 'active',
  driver_id    CHAR(36)     NULL,
  created_at   DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id),
  UNIQUE KEY uq_buses_number (bus_number),
  UNIQUE KEY uq_buses_plate (plate_number),
  KEY idx_buses_driver (driver_id),
  KEY idx_buses_status (status),
  CONSTRAINT fk_buses_driver FOREIGN KEY (driver_id) REFERENCES drivers(id) ON DELETE SET NULL,
  CONSTRAINT chk_buses_status CHECK (status IN ('active','maintenance','inactive')),
  CONSTRAINT chk_buses_capacity CHECK (capacity IS NULL OR capacity >= 0)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- routes
-- ---------------------------------------------------------------------
CREATE TABLE routes (
  id             CHAR(36)     NOT NULL DEFAULT (UUID()),
  route_name     VARCHAR(100) NOT NULL,
  start_point    VARCHAR(150) NULL,
  end_point      VARCHAR(150) NULL,
  departure_time VARCHAR(20)  NULL,
  arrival_time   VARCHAR(20)  NULL,
  bus_id         CHAR(36)     NULL,
  created_at     DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id),
  KEY idx_routes_bus (bus_id),
  CONSTRAINT fk_routes_bus FOREIGN KEY (bus_id) REFERENCES buses(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- students
-- ---------------------------------------------------------------------
CREATE TABLE students (
  id           CHAR(36)     NOT NULL DEFAULT (UUID()),
  name         VARCHAR(100) NOT NULL,
  grade        VARCHAR(30)  NULL,
  phone        VARCHAR(30)  NULL,
  parent_name  VARCHAR(100) NULL,
  parent_phone VARCHAR(30)  NULL,
  address      VARCHAR(255) NULL,
  route_id     CHAR(36)     NULL,
  created_at   DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id),
  KEY idx_students_route (route_id),
  KEY idx_students_name (name),
  CONSTRAINT fk_students_route FOREIGN KEY (route_id) REFERENCES routes(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- billing
-- ---------------------------------------------------------------------
CREATE TABLE billing (
  id          CHAR(36)      NOT NULL DEFAULT (UUID()),
  student_id  CHAR(36)      NOT NULL,
  amount      DECIMAL(10,2) NOT NULL DEFAULT 0,
  status      VARCHAR(20)   NOT NULL DEFAULT 'pending',
  due_date    DATE          NULL,
  paid_date   DATE          NULL,
  description VARCHAR(255)  NULL,
  created_at  DATETIME(3)   NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id),
  KEY idx_billing_student (student_id),
  KEY idx_billing_status (status),
  KEY idx_billing_due (due_date),
  CONSTRAINT fk_billing_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  CONSTRAINT chk_billing_status CHECK (status IN ('paid','pending','overdue')),
  CONSTRAINT chk_billing_amount CHECK (amount >= 0)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Triggers: paid_date always follows status
-- (paid -> today if empty, anything else -> NULL)
-- ---------------------------------------------------------------------
CREATE TRIGGER trg_billing_before_insert BEFORE INSERT ON billing
FOR EACH ROW
  SET NEW.paid_date = CASE WHEN NEW.status = 'paid' THEN COALESCE(NEW.paid_date, CURDATE()) ELSE NULL END;

CREATE TRIGGER trg_billing_before_update BEFORE UPDATE ON billing
FOR EACH ROW
  SET NEW.paid_date = CASE WHEN NEW.status = 'paid' THEN COALESCE(NEW.paid_date, CURDATE()) ELSE NULL END;

-- ---------------------------------------------------------------------
-- Views (handy for reports in Workbench)
-- ---------------------------------------------------------------------
CREATE VIEW billing_details AS
SELECT b.id, b.student_id, s.name AS student_name, s.grade,
       b.amount, b.status, b.due_date, b.paid_date, b.description, b.created_at
FROM billing b
JOIN students s ON s.id = b.student_id;

CREATE VIEW route_summary AS
SELECT r.id, r.route_name, r.start_point, r.end_point,
       r.departure_time, r.arrival_time,
       bu.bus_number, bu.capacity,
       d.name AS driver_name,
       (SELECT COUNT(*) FROM students st WHERE st.route_id = r.id) AS student_count
FROM routes r
LEFT JOIN buses bu  ON bu.id = r.bus_id
LEFT JOIN drivers d ON d.id = bu.driver_id;

CREATE VIEW dashboard_stats AS
SELECT
  (SELECT COUNT(*) FROM drivers)  AS total_drivers,
  (SELECT COUNT(*) FROM buses)    AS total_buses,
  (SELECT COUNT(*) FROM routes)   AS total_routes,
  (SELECT COUNT(*) FROM students) AS total_students,
  (SELECT COALESCE(SUM(amount),0) FROM billing WHERE status = 'paid')    AS revenue_paid,
  (SELECT COALESCE(SUM(amount),0) FROM billing WHERE status = 'pending') AS revenue_pending,
  (SELECT COALESCE(SUM(amount),0) FROM billing WHERE status = 'overdue') AS revenue_overdue;


-- ---------------------------------------------------------------------
-- Admin login (password is stored as a BCrypt hash, never as plain text)
-- ---------------------------------------------------------------------
INSERT INTO users (name, email, password_hash, role) VALUES
  ('Administrator', 'admin@busfleet.com', '$2b$10$Ujiz85ORxQyPrrtRJxwtX.VvsqQGxJ9Lqg8Mfc8dKxkCo8ablmzD2', 'ADMIN');

-- ---------------------------------------------------------------------
-- DEMO DATA (optional). Delete everything below this line for an empty system.
-- ---------------------------------------------------------------------
SET @d1 = UUID(); SET @d2 = UUID(); SET @d3 = UUID();
INSERT INTO drivers (id, name, phone, email, license_number, status) VALUES
  (@d1, 'Abdul Karim', '01711-000001', 'karim@example.com', 'DL-1001', 'active'),
  (@d2, 'Rahim Uddin', '01711-000002', 'rahim@example.com', 'DL-1002', 'active'),
  (@d3, 'Salam Mia',   '01711-000003', 'salam@example.com', 'DL-1003', 'inactive');

SET @b1 = UUID(); SET @b2 = UUID(); SET @b3 = UUID();
INSERT INTO buses (id, bus_number, plate_number, capacity, model, status, driver_id) VALUES
  (@b1, 'BUS-01', 'DHAKA-METRO-11-1001', 40, 'Ashok Leyland',  'active',      @d1),
  (@b2, 'BUS-02', 'DHAKA-METRO-11-1002', 32, 'Tata Starbus',   'active',      @d2),
  (@b3, 'BUS-03', 'DHAKA-METRO-11-1003', 28, 'Toyota Coaster', 'maintenance', NULL);

SET @r1 = UUID(); SET @r2 = UUID();
INSERT INTO routes (id, route_name, start_point, end_point, departure_time, arrival_time, bus_id) VALUES
  (@r1, 'Uttara Route', 'Uttara Sector 7', 'School Campus', '07:00', '08:00', @b1),
  (@r2, 'Mirpur Route', 'Mirpur 10',       'School Campus', '07:15', '08:05', @b2);

SET @s1 = UUID(); SET @s2 = UUID(); SET @s3 = UUID();
INSERT INTO students (id, name, grade, phone, parent_name, parent_phone, address, route_id) VALUES
  (@s1, 'Anika Rahman', 'Class 5', '01811-100001', 'Mr. Rahman', '01911-100001', 'Uttara, Dhaka', @r1),
  (@s2, 'Tanvir Hasan', 'Class 7', '01811-100002', 'Mrs. Hasan', '01911-100002', 'Mirpur, Dhaka', @r2),
  (@s3, 'Nusrat Jahan', 'Class 3', '01811-100003', 'Mr. Alam',   '01911-100003', 'Uttara, Dhaka', @r1);

INSERT INTO billing (student_id, amount, status, due_date, description) VALUES
  (@s1, 1500.00, 'paid',    '2026-09-10', 'Monthly transport fee - September'),
  (@s2, 1500.00, 'pending', '2026-10-10', 'Monthly transport fee - October'),
  (@s3, 1500.00, 'overdue', '2026-09-05', 'Monthly transport fee - September');

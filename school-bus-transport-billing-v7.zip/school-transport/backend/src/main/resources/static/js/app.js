/* BusFleet - School Transport Management (plain JavaScript, no build step needed).
   Served by the Spring Boot backend at http://localhost:8080 */
(() => {
  'use strict';

  const CURRENCY = '৳';           // change to '$' if you prefer
  const TOKEN_KEY = 'busfleet_token';
  const app = document.getElementById('app');
  const state = { user: null };

  // ------------------------------------------------------------ helpers
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const money = (n) => CURRENCY + Number(n || 0).toFixed(2);
  const $ = (sel, el = document) => el.querySelector(sel);

  async function api(path, { method = 'GET', body } = {}) {
    const headers = {};
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    const token = localStorage.getItem(TOKEN_KEY);
    if (token) headers['Authorization'] = 'Bearer ' + token;

    let res;
    try {
      res = await fetch(path, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined });
    } catch {
      throw new Error('Cannot reach the server. Is the backend running?');
    }
    if (res.status === 401 && !path.startsWith('/api/auth/login')) {
      localStorage.removeItem(TOKEN_KEY);
      state.user = null;
      renderLogin();
      throw new Error('Session expired. Please sign in again.');
    }
    if (!res.ok) {
      let msg = 'Request failed (' + res.status + ')';
      try { const b = await res.json(); if (b && b.error) msg = b.error; } catch { /* no body */ }
      throw new Error(msg);
    }
    if (res.status === 204) return null;
    return res.json();
  }

  // ------------------------------------------------------------ entity setup
  const STATUS = (values) => values.map((v) => ({ value: v, label: v[0].toUpperCase() + v.slice(1) }));

  const ENTITIES = {
    drivers: {
      title: 'Drivers', singular: 'Driver', icon: '🧑‍✈️', sub: 'Manage bus drivers',
      fields: [
        { name: 'name', label: 'Full Name', required: true, placeholder: 'John Smith' },
        { name: 'phone', label: 'Phone', placeholder: '01711-000000' },
        { name: 'email', label: 'Email', type: 'email', placeholder: 'driver@example.com' },
        { name: 'license_number', label: 'License Number', placeholder: 'DL-1001' },
        { name: 'status', label: 'Status', type: 'select', options: STATUS(['active', 'inactive']), default: 'active' },
      ],
      columns: [
        { label: 'Name', get: (r) => r.name, strong: true },
        { label: 'Phone', get: (r) => r.phone },
        { label: 'Email', get: (r) => r.email },
        { label: 'License', get: (r) => r.license_number },
        { label: 'Status', get: (r) => r.status, badge: true },
      ],
    },
    students: {
      title: 'Students', singular: 'Student', icon: '🎓', sub: 'Manage students and their routes',
      fields: [
        { name: 'name', label: 'Student Name', required: true },
        { name: 'grade', label: 'Grade', placeholder: 'Class 5' },
        { name: 'phone', label: 'Phone' },
        { name: 'parent_name', label: 'Parent Name' },
        { name: 'parent_phone', label: 'Parent Phone' },
        { name: 'address', label: 'Address' },
        { name: 'route_id', label: 'Route', type: 'select', from: 'routes', optionLabel: (r) => r.route_name, empty: 'Unassigned' },
      ],
      columns: [
        { label: 'Name', get: (r) => r.name, strong: true },
        { label: 'Grade', get: (r) => r.grade },
        { label: 'Parent', get: (r) => r.parent_name },
        { label: 'Parent Phone', get: (r) => r.parent_phone },
        { label: 'Route', get: (r) => (r.routes && r.routes.route_name) || 'Unassigned' },
      ],
    },
    routes: {
      title: 'Routes', singular: 'Route', icon: '🗺️', sub: 'Plan bus routes and timings',
      fields: [
        { name: 'route_name', label: 'Route Name', required: true, placeholder: 'Route A - North Side' },
        { name: 'start_point', label: 'Start Point', placeholder: 'School Campus' },
        { name: 'end_point', label: 'End Point', placeholder: 'North District' },
        { name: 'departure_time', label: 'Departure Time', type: 'time' },
        { name: 'arrival_time', label: 'Arrival Time', type: 'time' },
        { name: 'bus_id', label: 'Assigned Bus', type: 'select', from: 'buses', optionLabel: (b) => b.bus_number, empty: 'Unassigned' },
      ],
      columns: [
        { label: 'Route Name', get: (r) => r.route_name, strong: true },
        { label: 'Path', get: (r) => (r.start_point || '—') + '  →  ' + (r.end_point || '—') },
        { label: 'Departure', get: (r) => r.departure_time },
        { label: 'Arrival', get: (r) => r.arrival_time },
        { label: 'Bus', get: (r) => (r.buses && r.buses.bus_number) || 'Unassigned' },
      ],
    },
    buses: {
      title: 'Buses', singular: 'Bus', icon: '🚌', sub: 'Manage the fleet',
      fields: [
        { name: 'bus_number', label: 'Bus Number', required: true, placeholder: 'BUS-01' },
        { name: 'plate_number', label: 'Plate Number' },
        { name: 'capacity', label: 'Capacity', type: 'number', min: 0, default: 0 },
        { name: 'model', label: 'Model' },
        { name: 'driver_id', label: 'Driver', type: 'select', from: 'drivers', optionLabel: (d) => d.name, filter: (d) => d.status === 'active', empty: 'Unassigned' },
        { name: 'status', label: 'Status', type: 'select', options: STATUS(['active', 'maintenance', 'inactive']), default: 'active' },
      ],
      columns: [
        { label: 'Bus No.', get: (r) => r.bus_number, strong: true },
        { label: 'Plate', get: (r) => r.plate_number },
        { label: 'Capacity', get: (r) => r.capacity },
        { label: 'Model', get: (r) => r.model },
        { label: 'Driver', get: (r) => (r.drivers && r.drivers.name) || 'Unassigned' },
        { label: 'Status', get: (r) => r.status, badge: true },
      ],
    },
    billing: {
      title: 'Billing', singular: 'Invoice', icon: '💳', sub: 'Track transport fees',
      fields: [
        { name: 'student_id', label: 'Student', type: 'select', required: true, from: 'students', optionLabel: (s) => s.name, empty: 'Select a student' },
        { name: 'amount', label: 'Amount (' + CURRENCY + ')', type: 'number', required: true, min: 0, step: '0.01', placeholder: '1500.00' },
        { name: 'status', label: 'Status', type: 'select', options: STATUS(['pending', 'paid', 'overdue']), default: 'pending' },
        { name: 'due_date', label: 'Due Date', type: 'date' },
        { name: 'paid_date', label: 'Paid Date', type: 'date', showWhen: { status: 'paid' } },
        { name: 'description', label: 'Description', placeholder: 'Monthly transport fee - October' },
      ],
      columns: [
        { label: 'Student', get: (r) => (r.students && r.students.name) || 'Unknown', strong: true },
        { label: 'Amount', get: (r) => money(r.amount), strong: true },
        { label: 'Status', get: (r) => r.status, badge: true },
        { label: 'Due', get: (r) => r.due_date },
        { label: 'Paid On', get: (r) => r.paid_date },
        { label: 'Description', get: (r) => r.description },
      ],
    },
  };

  const ICONS = {
    dashboard: '<rect x="3" y="3" width="7" height="9" rx="1"/><rect x="14" y="3" width="7" height="5" rx="1"/><rect x="14" y="12" width="7" height="9" rx="1"/><rect x="3" y="16" width="7" height="5" rx="1"/>',
    buses: '<path d="M8 6v6m8-6v6M4 17V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v11H4Z"/><path d="M4 13h16M5 17v2a1 1 0 0 0 2 0v-2m10 0v2a1 1 0 0 0 2 0v-2"/><circle cx="7.5" cy="15" r=".5"/><circle cx="16.5" cy="15" r=".5"/>',
    drivers: '<circle cx="12" cy="8" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2"/>',
    routes: '<circle cx="6" cy="19" r="2"/><circle cx="18" cy="5" r="2"/><path d="M8 19h6a4 4 0 0 0 0-8h-4a4 4 0 0 1 0-8h6"/>',
    students: '<path d="m2 10 10-5 10 5-10 5-10-5Zm4 2v5c3 3 9 3 12 0v-5M22 10v7"/>',
    billing: '<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20M6 15h3"/>',
    logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4m7 14 5-5-5-5m5 5H9"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
    edit: '<path d="M12 20h9M16.5 3.5a2.12 2.12 0 0 1 3 3L9 17l-4 1 1-4 10.5-10.5Z"/>',
    delete: '<path d="M3 6h18m-2 0-1 14H6L5 6m3 0V4h8v2m-6 4v7m4-7v7"/>',
    menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
    close: '<path d="M18 6 6 18M6 6l12 12"/>',
    arrow: '<path d="M5 12h14m-6-6 6 6-6 6"/>',
  };
  const icon = (name, size = 18) => `<svg aria-hidden="true" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${ICONS[name] || ICONS.dashboard}</svg>`;
  const NAV = [
    ['dashboard', 'Dashboard'], ['buses', 'Buses'], ['drivers', 'Drivers'],
    ['routes', 'Routes'], ['students', 'Students'], ['billing', 'Billing'],
  ];

  

  // ------------------------------------------------------------ login
  function renderLogin() {
    app.innerHTML = `
      <div class="login-page">
        <div class="login-brand"><div class="brand-mark">B</div><span>School Bus</span><span class="login-brand-tag">TRANSPORT &amp; BILLING</span></div>
        <div class="login-layout">
          <div class="login-intro"><p class="eyebrow">SCHOOL BUS TRANSPORT / BILLING</p><h1>Every journey,<br><em>under control.</em></h1><p>One workspace for your fleet, routes, drivers, students and transport fees.</p><div class="login-rule"></div><span>School Bus Transport &amp; Billing System</span></div>
          <div class="login-card"><div class="login-card-top"><span class="login-symbol">${icon('buses', 24)}</span><p class="eyebrow">WELCOME TO BUSFLEET</p><h2>Access your workspace</h2><p>Sign in to manage your transport network.</p></div>
            <div id="login-error" class="error hidden" role="alert"></div>
            <form id="login-form" autocomplete="on"><div class="field"><label for="login-email">Email address</label><input id="login-email" class="input" type="email" name="email" required placeholder="you@school.com" autocomplete="username"></div>
              <div class="field"><label for="login-password">Password</label><input id="login-password" class="input" type="password" name="password" required placeholder="Enter your password" autocomplete="current-password"></div>
              <button class="btn btn-primary btn-block" id="login-btn" type="submit">Sign in ${icon('arrow', 17)}</button></form>
            <p class="login-foot">Authorized access only</p>
          </div>
        </div>
      </div>`;
    $('#login-form').onsubmit = async (e) => {
      e.preventDefault();
      const btn = $('#login-btn'), err = $('#login-error');
      err.classList.add('hidden'); btn.disabled = true;
      try {
        const f = e.target;
        const res = await api('/api/auth/login', {
          method: 'POST', body: { email: f.elements.email.value, password: f.elements.password.value },
        });
        localStorage.setItem(TOKEN_KEY, res.token);
        state.user = res.user;
        renderShell();
      } catch (ex) {
        err.textContent = ex.message; err.classList.remove('hidden'); btn.disabled = false;
      }
    };
  }

  

  // ------------------------------------------------------------ shell + routing
  function renderShell() {
    app.innerHTML = `<div class="shell"><aside class="sidebar" id="sidebar">
        <div class="brand-row"><div class="logo-sm">B</div><div><strong>School Bus</strong><small>TRANSPORT &amp; BILLING</small></div><button class="mobile-close icon-btn" id="close-menu" aria-label="Close menu">${icon('close')}</button></div>
        <p class="nav-label">WORKSPACE</p><nav class="nav" id="nav">${NAV.map(([key, label]) => `<a href="#/${key}" data-key="${key}">${icon(key)}<span>${label}</span></a>`).join('')}</nav>
        <div class="user-box"><div class="avatar">${esc((state.user.name || state.user.email || 'U').slice(0, 2).toUpperCase())}</div><div class="user-details"><strong>${esc(state.user.name || 'Administrator')}</strong><small>${esc(state.user.email)}</small></div><button type="button" id="logout" title="Sign out" aria-label="Sign out">${icon('logout', 17)}</button></div>
      </aside><div class="mobile-scrim" id="scrim"></div><div class="main-area"><header class="topbar"><button class="mobile-menu icon-btn" id="open-menu" aria-label="Open menu">${icon('menu')}</button><div><h1 id="page-title">Overview</h1><p>School bus transport &amp; billing</p></div><div class="topbar-right"><span class="system-pill"><i></i> System overview</span><div class="top-avatar">${esc((state.user.name || state.user.email || 'U').slice(0, 2).toUpperCase())}</div></div></header><main class="main" id="view"></main><footer class="app-footer"><span>School Bus Transport &amp; Billing System</span><span>Connected to your school transport database</span></footer></div></div>`;
    $('#logout').onclick = () => { localStorage.removeItem(TOKEN_KEY); state.user = null; renderLogin(); };
    const closeMenu = () => $('#sidebar').classList.remove('open');
    $('#open-menu').onclick = () => $('#sidebar').classList.add('open');
    $('#close-menu').onclick = closeMenu;
    $('#scrim').onclick = closeMenu;
    $('#nav').onclick = (e) => { if (e.target.closest('a')) closeMenu(); };
    route();
  }
  function route() {
    if (!state.user) return;
    const key = (location.hash.replace('#/', '') || 'dashboard');
    const page = key === 'dashboard' || ENTITIES[key] ? key : 'dashboard';
    document.querySelectorAll('#nav a').forEach((a) => a.classList.toggle('active', a.dataset.key === page));
    $('#page-title').textContent = page === 'dashboard' ? 'Operational overview' : ENTITIES[page].title;
    if (page === 'dashboard') renderDashboard(); else renderCrud(page);
  }
  window.addEventListener('hashchange', route);
  const spinner = '<div class="spinner"></div>';
  const errorBox = (msg) => `<div class="error">${esc(msg)}</div>`;

  

  // ------------------------------------------------------------ dashboard
  async function renderDashboard() {
    const view = $('#view'); view.innerHTML = spinner;
    try {
      const [drivers, students, buses, routes, billing] = await Promise.all(['drivers', 'students', 'buses', 'routes', 'billing'].map((t) => api('/api/' + t)));
      const sum = (status) => billing.filter((b) => !status || b.status === status).reduce((total, b) => total + Number(b.amount), 0);
      const onRoad = buses.filter(b => b.status === 'active').length;
      const card = (label, value, note, cls = '') => `<section class="panel metric ${cls}"><span class="eyebrow">${label}</span><strong>${value}</strong><small>${note}</small></section>`;
      const badge = (v) => `<span class="badge badge-${['active','paid','pending','overdue','maintenance','inactive'].includes(v) ? v : 'neutral'}">${esc(v || 'Unassigned')}</span>`;
      view.innerHTML = `<div class="dashboard-heading"><div><p class="eyebrow">LIVE OPERATIONS / OVERVIEW</p><h2>Good to see you.</h2><p>Your school transport network at a glance.</p></div><span class="live-badge"><i></i> DATABASE CONNECTED</span></div>
        <div class="dashboard-grid">
          ${card('BUSES ON ROAD', onRoad, `${buses.length - onRoad} not active`, 'metric-feature')}
          <section class="panel routes-panel"><div class="panel-heading"><h3>Route activity</h3><span class="panel-count">${routes.length} routes scheduled</span></div><div class="route-list">${routes.length ? routes.slice(0, 5).map((r, i) => `<div class="route-row"><span class="route-code">R${String(i+1).padStart(2,'0')}</span><div class="route-info"><strong>${esc(r.route_name)}</strong><small>${esc(r.start_point || 'Start not set')} → ${esc(r.end_point || 'End not set')}</small></div><span class="route-bus">${esc(r.buses?.bus_number || 'Unassigned')}</span></div>`).join('') : '<p class="empty">No routes yet.</p>'}</div><a class="text-link" href="#/routes">View all routes ${icon('arrow', 15)}</a></section>
          ${card('ACTIVE DRIVERS', drivers.filter(d => d.status === 'active').length, `${drivers.length} drivers total`, 'metric-small')}
          ${card('ENROLLED STUDENTS', students.length, 'Across all routes', 'metric-small')}
          <section class="panel roster-panel"><div class="panel-heading"><h3>Driver roster</h3><span class="panel-count">${drivers.length} total</span></div><div class="roster-head"><span>DRIVER</span><span>CONTACT</span><span>STATUS</span></div>${drivers.slice(0, 4).map(d => `<div class="roster-row"><strong>${esc(d.name)}</strong><span>${esc(d.phone || '—')}</span>${badge(d.status)}</div>`).join('') || '<p class="empty">No drivers yet.</p>'}<a class="text-link" href="#/drivers">View drivers ${icon('arrow',15)}</a></section>
          <section class="panel billing-panel"><div class="panel-heading"><h3>Billing & revenue</h3><span class="panel-count">All records</span></div><div class="billing-metrics"><div><span>Collected</span><strong>${money(sum('paid'))}</strong></div><div><span>Pending</span><strong>${money(sum('pending'))}</strong></div><div><span>Overdue</span><strong>${money(sum('overdue'))}</strong></div></div><a class="text-link" href="#/billing">View billing ${icon('arrow', 15)}</a></section>
          <section class="panel fleet-panel"><span class="eyebrow">FLEET HEALTH</span><strong>${buses.filter(b => b.status === 'maintenance').length}</strong><small>Vehicles in maintenance</small><div class="fleet-divider"></div><span>${buses.length} total vehicles</span></section>
        </div>`;
    } catch (e) { view.innerHTML = errorBox(e.message); }
  }

  

  // ------------------------------------------------------------ generic CRUD page
  async function renderCrud(key) {
    const ent = ENTITIES[key];
    const view = $('#view');
    view.innerHTML = spinner;
    let rows;
    try { rows = await api('/api/' + key); } catch (e) { view.innerHTML = errorBox(e.message); return; }

    view.innerHTML = `
      <div class="directory-heading"><div><p class="eyebrow">BUSFLEET / ${ent.title.toUpperCase()}</p><h2>${ent.title} directory</h2><p>${ent.sub} · ${rows.length} records</p></div><span class="live-badge"><i></i> DATABASE CONNECTED</span></div>
      <div class="panel directory-panel"><div class="directory-toolbar"><div><h3>All ${ent.title.toLowerCase()}</h3><span>${rows.length} records</span></div><div class="toolbar"><label class="search-wrap">${icon('search', 16)}<input id="search" placeholder="Search ${ent.title.toLowerCase()}..." aria-label="Search ${ent.title.toLowerCase()}"></label><button class="btn btn-primary" id="add">${icon('plus', 17)} Add ${ent.singular}</button></div></div><div class="table-scroll" id="table"></div><div class="table-footer">Showing ${rows.length} of ${rows.length} records <span>BUSFLEET / ${ent.title.toUpperCase()}</span></div></div>`;

    const cell = (col, r) => {
      const v = col.get(r);
      const text = v === null || v === undefined || v === '' ? '—' : v;
      if (col.badge && text !== '—') return `<td><span class="badge badge-${['active','paid','pending','overdue','maintenance','inactive'].includes(v) ? v : 'neutral'}">${esc(v)}</span></td>`;
      return `<td class="${col.strong ? 'strong' : ''}">${esc(text)}</td>`;
    };

    const draw = () => {
      const q = $('#search').value.trim().toLowerCase();
      const list = q ? rows.filter((r) => ent.columns.some((c) => String(c.get(r) ?? '').toLowerCase().includes(q))) : rows;
      $('#table').innerHTML = list.length === 0
        ? `<div class="empty">${rows.length ? 'No matches found' : 'No ' + ent.title.toLowerCase() + ' yet. Click "Add ' + ent.singular + '" to create one.'}</div>`
        : `<table><thead><tr>${ent.columns.map((c) => `<th>${c.label}</th>`).join('')}<th></th></tr></thead>
           <tbody>${list.map((r) => `<tr>${ent.columns.map((c) => cell(c, r)).join('')}
             <td class="actions"><button class="icon-btn" title="Edit" aria-label="Edit ${esc(ent.singular)}" data-act="edit" data-id="${esc(r.id)}">${icon('edit', 17)}</button><button class="icon-btn danger-icon" title="Delete" aria-label="Delete ${esc(ent.singular)}" data-act="del" data-id="${esc(r.id)}">${icon('delete', 17)}</button></td></tr>`).join('')}</tbody></table>`;
    };
    draw();

    $('#search').oninput = draw;
    $('#add').onclick = () => openForm(key, null, () => renderCrud(key));
    $('#table').onclick = async (e) => {
      const btn = e.target.closest('button[data-act]');
      if (!btn) return;
      const row = rows.find((r) => r.id === btn.dataset.id);
      if (!row) return;
      if (btn.dataset.act === 'edit') {
        openForm(key, row, () => renderCrud(key));
      } else if (confirm('Delete this ' + ent.singular.toLowerCase() + '? This cannot be undone.')) {
        try { await api('/api/' + key + '/' + row.id, { method: 'DELETE' }); renderCrud(key); }
        catch (ex) { alert(ex.message); }
      }
    };
  }

  // ------------------------------------------------------------ add / edit modal
  async function openForm(key, row, done) {
    const ent = ENTITIES[key];

    // load dropdown data (drivers for buses, routes for students, ...)
    const lookups = {};
    try {
      await Promise.all(ent.fields.filter((f) => f.from).map(async (f) => { lookups[f.name] = await api('/api/' + f.from); }));
    } catch (e) { alert(e.message); return; }

    const optionsFor = (f) => {
      if (f.from) {
        const items = (lookups[f.name] || []).filter(f.filter || (() => true));
        return [{ value: '', label: f.empty || 'None' }].concat(items.map((i) => ({ value: i.id, label: f.optionLabel(i) })));
      }
      return f.options;
    };

    const valueOf = (f) => {
      const v = row ? row[f.name] : f.default;
      return v === null || v === undefined ? '' : v;
    };

    const inputHtml = (f) => {
      const v = valueOf(f);
      if (f.type === 'select') {
        return `<select class="input" name="${f.name}">${optionsFor(f).map((o) =>
          `<option value="${esc(o.value)}" ${String(o.value) === String(v) ? 'selected' : ''}>${esc(o.label)}</option>`).join('')}</select>`;
      }
      return `<input class="input" name="${f.name}" type="${f.type || 'text'}" value="${esc(v)}" placeholder="${esc(f.placeholder || '')}"
        ${f.min !== undefined ? `min="${f.min}"` : ''} ${f.step ? `step="${f.step}"` : ''}>`;
    };

    const backdrop = document.createElement('div');
    backdrop.className = 'backdrop';
    backdrop.innerHTML = `
      <div class="modal" role="dialog" aria-modal="true" aria-label="${row ? 'Edit' : 'Add'} ${ent.singular}">
        <div class="modal-head"><div><p class="eyebrow">BUSFLEET / ${ent.title.toUpperCase()}</p><h3>${row ? 'Edit' : 'Add New'} ${ent.singular}</h3></div><button type="button" class="icon-btn" id="close-form" aria-label="Close">${icon('close')}</button></div>
        <div class="error hidden" id="form-error"></div>
        <form id="entity-form" novalidate>
          <div class="grid2">
            ${ent.fields.map((f) => `<div class="field" data-field="${f.name}">
              <label>${esc(f.label)}${f.required ? ' *' : ''}</label>${inputHtml(f)}</div>`).join('')}
          </div>
          <div class="footer">
            <button type="button" class="btn btn-ghost" id="cancel">Cancel</button>
            <button type="submit" class="btn btn-primary" id="save">${row ? 'Save Changes' : 'Create'}</button>
          </div>
        </form>
      </div>`;
    document.body.appendChild(backdrop);
    const form = $('#entity-form', backdrop);
    const close = () => backdrop.remove();
    $('#cancel', backdrop).onclick = close;
    $('#close-form', backdrop).onclick = close;
    backdrop.addEventListener('mousedown', (e) => { if (e.target === backdrop) close(); });

    // fields that only appear for certain values (e.g. Paid Date when status = paid)
    const applyVisibility = () => {
      ent.fields.filter((f) => f.showWhen).forEach((f) => {
        const show = Object.entries(f.showWhen).every(([k, v]) => form.elements[k].value === v);
        $(`[data-field="${f.name}"]`, backdrop).classList.toggle('hidden', !show);
      });
    };
    form.addEventListener('change', applyVisibility);
    applyVisibility();

    form.onsubmit = async (e) => {
      e.preventDefault();
      const errBox = $('#form-error', backdrop);
      errBox.classList.add('hidden');

      const payload = {};
      for (const f of ent.fields) {
        let v = form.elements[f.name].value.trim();
        if (f.required && v === '') { errBox.textContent = f.label.replace(/ \(.*\)/, '') + ' is required'; errBox.classList.remove('hidden'); return; }
        if (f.type === 'number') v = v === '' ? (f.default ?? null) : Number(v);
        else if (v === '') v = null;
        payload[f.name] = v;
      }
      if (key === 'billing') {
        if (!(payload.amount > 0)) { errBox.textContent = 'Amount must be greater than 0'; errBox.classList.remove('hidden'); return; }
        if (payload.status !== 'paid') payload.paid_date = null;   // the database fills it when paid
      }

      const save = $('#save', backdrop);
      save.disabled = true;
      try {
        await api('/api/' + key + (row ? '/' + row.id : ''), { method: row ? 'PUT' : 'POST', body: payload });
        close();
        done();
      } catch (ex) {
        errBox.textContent = ex.message;
        errBox.classList.remove('hidden');
        save.disabled = false;
      }
    };
    const first = form.querySelector('input,select');
    if (first) first.focus();
  }

  // ------------------------------------------------------------ start
  async function boot() {
    if (!localStorage.getItem(TOKEN_KEY)) return renderLogin();
    app.innerHTML = spinner;
    try {
      state.user = await api('/api/auth/me');
      renderShell();
    } catch {
      localStorage.removeItem(TOKEN_KEY);
      renderLogin();
    }
  }
  boot();
})();

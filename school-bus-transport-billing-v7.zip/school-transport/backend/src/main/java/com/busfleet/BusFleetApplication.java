package com.busfleet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.UserDetailsServiceAutoConfiguration;

@SpringBootApplication(exclude = UserDetailsServiceAutoConfiguration.class)
public class BusFleetApplication {
    public static void main(String[] args) {
        SpringApplication.run(BusFleetApplication.class, args);
    }
}

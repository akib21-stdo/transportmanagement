package com.busfleet.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

@Entity
@Table(name = "drivers")
public class Driver extends BaseEntity {

    @NotBlank(message = "Name is required")
    public String name;

    public String phone;

    @Email(message = "Invalid email address")
    public String email;

    @Column(name = "license_number")
    public String licenseNumber;

    @Pattern(regexp = "active|inactive", message = "must be active or inactive")
    public String status = "active";
}

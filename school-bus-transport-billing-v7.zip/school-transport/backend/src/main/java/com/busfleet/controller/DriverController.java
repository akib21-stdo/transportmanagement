package com.busfleet.controller;

import com.busfleet.model.Driver;
import com.busfleet.repository.DriverRepository;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/drivers")
public class DriverController extends CrudController<Driver> {
    public DriverController(DriverRepository repo) {
        super(repo, "Driver");
    }
}

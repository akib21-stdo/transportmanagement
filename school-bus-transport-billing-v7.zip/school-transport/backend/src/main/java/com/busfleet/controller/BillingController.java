package com.busfleet.controller;

import com.busfleet.model.Billing;
import com.busfleet.repository.BillingRepository;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/billing")
public class BillingController extends CrudController<Billing> {
    public BillingController(BillingRepository repo) {
        super(repo, "Invoice");
    }
}

package com.busfleet.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.PositiveOrZero;

@Entity
@Table(name = "buses")
public class Bus extends BaseEntity {

    @NotBlank(message = "Bus number is required")
    @Column(name = "bus_number")
    public String busNumber;

    @Column(name = "plate_number")
    public String plateNumber;

    @PositiveOrZero(message = "Capacity cannot be negative")
    public Integer capacity = 0;

    public String model;

    @Pattern(regexp = "active|maintenance|inactive", message = "must be active, maintenance or inactive")
    public String status = "active";

    // written by the client as driver_id ...
    @Column(name = "driver_id")
    public String driverId;

    // ... and read back as the nested "drivers" object
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "driver_id", insertable = false, updatable = false)
    @JsonProperty(value = "drivers", access = JsonProperty.Access.READ_ONLY)
    public Driver driver;
}

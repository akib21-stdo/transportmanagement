package com.busfleet.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Pattern;

import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "billing")
public class Billing extends BaseEntity {

    @NotBlank(message = "Student is required")
    @Column(name = "student_id")
    public String studentId;

    @NotNull(message = "Amount is required")
    @PositiveOrZero(message = "Amount cannot be negative")
    public BigDecimal amount;

    @Pattern(regexp = "paid|pending|overdue", message = "must be paid, pending or overdue")
    public String status = "pending";

    @Column(name = "due_date")
    public LocalDate dueDate;

    // the database trigger keeps this in sync with status
    @Column(name = "paid_date")
    public LocalDate paidDate;

    public String description;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "student_id", insertable = false, updatable = false)
    @JsonProperty(value = "students", access = JsonProperty.Access.READ_ONLY)
    public Student student;
}

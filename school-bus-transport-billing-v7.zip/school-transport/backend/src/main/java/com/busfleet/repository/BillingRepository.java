package com.busfleet.repository;

import com.busfleet.model.Billing;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BillingRepository extends JpaRepository<Billing, String> {
}

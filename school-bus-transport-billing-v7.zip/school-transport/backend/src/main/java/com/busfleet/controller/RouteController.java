package com.busfleet.controller;

import com.busfleet.model.BusRoute;
import com.busfleet.repository.BusRouteRepository;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/routes")
public class RouteController extends CrudController<BusRoute> {
    public RouteController(BusRouteRepository repo) {
        super(repo, "Route");
    }
}

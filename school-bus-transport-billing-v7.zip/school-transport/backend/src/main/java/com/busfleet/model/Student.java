package com.busfleet.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;

@Entity
@Table(name = "students")
public class Student extends BaseEntity {

    @NotBlank(message = "Name is required")
    public String name;

    public String grade;
    public String phone;

    @Column(name = "parent_name")
    public String parentName;

    @Column(name = "parent_phone")
    public String parentPhone;

    public String address;

    @Column(name = "route_id")
    public String routeId;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "route_id", insertable = false, updatable = false)
    @JsonProperty(value = "routes", access = JsonProperty.Access.READ_ONLY)
    public BusRoute route;
}

package com.busfleet.controller;

import com.busfleet.model.Bus;
import com.busfleet.repository.BusRepository;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/buses")
public class BusController extends CrudController<Bus> {
    public BusController(BusRepository repo) {
        super(repo, "Bus");
    }
}

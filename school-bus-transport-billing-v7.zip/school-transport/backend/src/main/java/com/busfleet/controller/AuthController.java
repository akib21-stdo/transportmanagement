package com.busfleet.controller;

import com.busfleet.security.JwtService;
import jakarta.validation.constraints.NotBlank;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

/** Simple login: one fixed user, set in application.properties. */
@RestController
@RequestMapping("/api/auth")
@Validated
public class AuthController {

    public record LoginRequest(@NotBlank String email, @NotBlank String password) {}

    public record UserDto(String name, String email) {}

    public record AuthResponse(String token, UserDto user) {}

    private final JwtService jwt;
    private final String name;
    private final String email;
    private final String password;

    public AuthController(JwtService jwt,
                          @Value("${app.login.name}") String name,
                          @Value("${app.login.email}") String email,
                          @Value("${app.login.password}") String password) {
        this.jwt = jwt;
        this.name = name;
        this.email = email;
        this.password = password;
    }

    @PostMapping("/login")
    public AuthResponse login(@RequestBody LoginRequest req) {
        boolean ok = req.email() != null && req.password() != null
                && email.equalsIgnoreCase(req.email().trim())
                && password.equals(req.password());
        if (!ok) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid email or password");
        }
        return new AuthResponse(jwt.generate(email), new UserDto(name, email));
    }

    @GetMapping("/me")
    public UserDto me(Authentication auth) {
        return new UserDto(name, auth.getName());
    }
}

package com.busfleet.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;

@Entity
@Table(name = "routes")
public class BusRoute extends BaseEntity {

    @NotBlank(message = "Route name is required")
    @Column(name = "route_name")
    public String routeName;

    @Column(name = "start_point")
    public String startPoint;

    @Column(name = "end_point")
    public String endPoint;

    @Column(name = "departure_time")
    public String departureTime;

    @Column(name = "arrival_time")
    public String arrivalTime;

    @Column(name = "bus_id")
    public String busId;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "bus_id", insertable = false, updatable = false)
    @JsonProperty(value = "buses", access = JsonProperty.Access.READ_ONLY)
    public Bus bus;
}

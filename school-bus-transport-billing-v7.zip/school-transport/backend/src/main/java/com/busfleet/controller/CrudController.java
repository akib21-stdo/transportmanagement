package com.busfleet.controller;

import com.busfleet.exception.NotFoundException;
import com.busfleet.model.BaseEntity;
import jakarta.validation.Valid;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.util.List;

/** list / get / create / update / delete for one table. */
public abstract class CrudController<T extends BaseEntity> {

    private final JpaRepository<T, String> repo;
    private final String label;

    protected CrudController(JpaRepository<T, String> repo, String label) {
        this.repo = repo;
        this.label = label;
    }

    @GetMapping
    public List<T> list() {
        return repo.findAll(Sort.by(Sort.Direction.DESC, "createdAt"));
    }

    @GetMapping("/{id}")
    public T get(@PathVariable String id) {
        return repo.findById(id).orElseThrow(() -> new NotFoundException(label + " not found"));
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public T create(@Valid @RequestBody T body) {
        body.id = null;
        T saved = repo.save(body);
        return repo.findById(saved.id).orElse(saved);
    }

    @PutMapping("/{id}")
    public T update(@PathVariable String id, @Valid @RequestBody T body) {
        if (!repo.existsById(id)) {
            throw new NotFoundException(label + " not found");
        }
        body.id = id;
        T saved = repo.save(body);
        return repo.findById(saved.id).orElse(saved);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id) {
        if (!repo.existsById(id)) {
            throw new NotFoundException(label + " not found");
        }
        repo.deleteById(id);
    }
}

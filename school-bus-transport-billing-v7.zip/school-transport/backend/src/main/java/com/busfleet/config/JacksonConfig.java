package com.busfleet.config;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.boot.autoconfigure.jackson.Jackson2ObjectMapperBuilderCustomizer;

import java.io.IOException;

@Configuration
public class JacksonConfig {

    /**
     * Empty form fields arrive as "" - store them as NULL instead.
     * (Keeps UNIQUE columns like license_number and plate_number working.)
     */
    @Bean
    Jackson2ObjectMapperBuilderCustomizer blankStringsToNull() {
        return (Jackson2ObjectMapperBuilder builder) -> builder.deserializerByType(String.class,
                new StdDeserializer<String>(String.class) {
                    @Override
                    public String deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
                        String value = p.getValueAsString();
                        return (value == null || value.isBlank()) ? null : value;
                    }
                });
    }
}

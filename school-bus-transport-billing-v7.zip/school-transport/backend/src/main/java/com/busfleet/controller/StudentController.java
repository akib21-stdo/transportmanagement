package com.busfleet.controller;

import com.busfleet.model.Student;
import com.busfleet.repository.StudentRepository;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/students")
public class StudentController extends CrudController<Student> {
    public StudentController(StudentRepository repo) {
        super(repo, "Student");
    }
}
